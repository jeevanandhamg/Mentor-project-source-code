package com.mentorondemand.mentorondemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mentorondemand.mentorondemand.model.Mentor;

public interface MentorRepository extends JpaRepository<Mentor, Long>{

	@Query("Select m From Mentor m where m.userName = :uname and m.password = :password")
	Mentor loginMentorCheck(@Param("uname") String uname,@Param("password") String password);

}
