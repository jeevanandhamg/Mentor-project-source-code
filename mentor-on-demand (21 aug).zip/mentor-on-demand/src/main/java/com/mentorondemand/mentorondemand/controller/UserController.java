package com.mentorondemand.mentorondemand.controller;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.mentorondemand.model.User;
import com.mentorondemand.mentorondemand.service.UserService;

@RestController
@RequestMapping("/user")
public class UserController {
	
	@Autowired
	UserService userService;
	
	//login check
	@PostMapping(value="/login")
	public User loginUserCheck(@PathVariable("uname") String uname,@PathVariable("password") String password)
	{
		
		return userService.loginUserCheck(uname,password);
		
	}
	
	//signup user
	@PostMapping(value="/signupUser")
	public User signupUser(@RequestBody User user)
	{
		return userService.signupUser(user);
	}
	
	//get all users
	@GetMapping(value="/Users")
	public List<User> getAllUser()
	{
		return userService.getAllUser();
	}
	
}
