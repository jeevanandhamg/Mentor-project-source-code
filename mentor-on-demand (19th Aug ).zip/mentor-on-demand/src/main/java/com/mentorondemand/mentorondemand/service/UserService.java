package com.mentorondemand.mentorondemand.service;

import com.mentorondemand.mentorondemand.model.User;

public interface UserService {

	User loginUserCheck(String uname, String password);

	User signupUser(User user);

}
