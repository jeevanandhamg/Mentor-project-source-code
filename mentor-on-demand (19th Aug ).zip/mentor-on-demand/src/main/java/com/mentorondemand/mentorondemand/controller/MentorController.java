package com.mentorondemand.mentorondemand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.mentorondemand.model.Mentor;
import com.mentorondemand.mentorondemand.service.MentorService;

@RestController
@RequestMapping("/mentor")
public class MentorController {

	@Autowired
	private MentorService mentorService;
	
	//get all mentor details 
	@GetMapping("/mentordet")
	public List<Mentor> getMentorDetails()
	{
		return mentorService.getMentorDetails();
	}
	
	//login mentor
	@PostMapping(value="/login")
	public Mentor loginMentorCheck(@PathVariable("uname") String uname,@PathVariable("password") String password)
	{
		
		return mentorService.loginMentorCheck(uname,password);
		
	}
	
	
}
