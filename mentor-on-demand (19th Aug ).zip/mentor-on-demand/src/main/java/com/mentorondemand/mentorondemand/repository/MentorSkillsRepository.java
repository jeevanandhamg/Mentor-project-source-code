package com.mentorondemand.mentorondemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mentorondemand.mentorondemand.model.MentorSkills;

public interface MentorSkillsRepository extends JpaRepository<MentorSkills, Long>{

}
