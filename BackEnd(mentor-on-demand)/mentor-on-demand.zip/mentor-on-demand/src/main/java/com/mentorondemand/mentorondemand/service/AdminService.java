package com.mentorondemand.mentorondemand.service;

import com.mentorondemand.mentorondemand.model.Admin;

public interface AdminService {

	Admin loginAdminCheck(String uname, String password);

	Admin signupAdmin(Admin admin);

	

}
