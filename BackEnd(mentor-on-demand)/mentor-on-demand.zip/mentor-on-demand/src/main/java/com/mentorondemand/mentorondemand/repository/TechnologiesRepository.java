package com.mentorondemand.mentorondemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mentorondemand.mentorondemand.model.Technologies;

public interface TechnologiesRepository extends JpaRepository<Technologies, Long>{

}
