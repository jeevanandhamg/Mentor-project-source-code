package com.mentorondemand.mentorondemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.mentorondemand.model.Technologies;
import com.mentorondemand.mentorondemand.repository.TechnologiesRepository;

@Service
public class TechnologiesServiceImpl implements TechnologiesService{

	
	@Autowired
	TechnologiesRepository technologiesRepository;
	
	@Override
	public List<Technologies> getAllTechnologies() {
		// TODO Auto-generated method stub
		return technologiesRepository.findAll();
	}

	@Override
	public Technologies createTechnology(Technologies technologies) {
		// TODO Auto-generated method stub
		return technologiesRepository.save(technologies);
	}

}
