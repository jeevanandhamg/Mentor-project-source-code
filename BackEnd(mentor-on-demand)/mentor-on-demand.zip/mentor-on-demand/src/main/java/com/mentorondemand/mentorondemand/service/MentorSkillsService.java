package com.mentorondemand.mentorondemand.service;

import java.util.List;

import com.mentorondemand.mentorondemand.model.MentorSkills;

public interface MentorSkillsService {

	MentorSkills updateMentorSkills = null;

	List<MentorSkills> getAllMentorSkills();

	MentorSkills updateMentorSkills(MentorSkills mentorSkills);

}
