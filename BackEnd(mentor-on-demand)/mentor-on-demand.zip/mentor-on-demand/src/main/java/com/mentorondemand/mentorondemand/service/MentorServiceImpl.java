package com.mentorondemand.mentorondemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.mentorondemand.model.Mentor;

import com.mentorondemand.mentorondemand.repository.MentorRepository;

@Service
public class MentorServiceImpl implements MentorService {

	@Autowired
	MentorRepository mentorRepository;
public List<Mentor> getAllMentor()
{
	return mentorRepository.findAll();
}
@Override
public Mentor loginMentorCheck(String uname, String password) {
	// TODO Auto-generated method stub
	return mentorRepository.loginMentorCheck(uname,password);
}

@Override
public Mentor signupMentor(Mentor mentor) {
	// TODO Auto-generated method stub
	return mentorRepository.save(mentor);
}
@Override
public Mentor blockMentor(Mentor mentor) {
	// TODO Auto-generated method stub
	return mentorRepository.save(mentor);
}
}
