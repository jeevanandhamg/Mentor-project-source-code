package com.mentorondemand.mentorondemand.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mentorondemand.mentorondemand.model.Trainings;


public interface TrainingsRepository extends JpaRepository<Trainings, Long>{

	@Query("Select t From Trainings t where t.uid.id=:uid and t.status=6")
	List<Trainings> getCompletedTrainings(@Param("uid") long uid);

	@Query("Select t From Trainings t where t.uid.id=:uid and t.status=5")
	List<Trainings> getUnderProgressTrainings(@Param("uid") long uid);

	@Query("Select t From Trainings t where t.uid.id=:uid and t.status=3 or t.status=2")
	List<Trainings> getApprovedTraining(@Param("uid") long uid);

}
