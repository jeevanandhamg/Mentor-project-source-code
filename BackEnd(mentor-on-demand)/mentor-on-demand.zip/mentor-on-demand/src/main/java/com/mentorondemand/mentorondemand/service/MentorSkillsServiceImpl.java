package com.mentorondemand.mentorondemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.mentorondemand.model.MentorSkills;
import com.mentorondemand.mentorondemand.repository.MentorSkillsRepository;

@Service
public class MentorSkillsServiceImpl implements MentorSkillsService{

	@Autowired
	MentorSkillsRepository mentorSkillsRepository;
	
	@Override
	public List<MentorSkills> getAllMentorSkills() {
		// TODO Auto-generated method stub
		return mentorSkillsRepository.findAll();
	}

	@Override
	public MentorSkills updateMentorSkills(MentorSkills mentorSkills) {
		// TODO Auto-generated method stub
		return mentorSkillsRepository.save(mentorSkills);
	}

}
