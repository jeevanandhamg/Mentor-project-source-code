package com.mentorondemand.mentorondemand.service;

import java.util.List;

import com.mentorondemand.mentorondemand.model.Trainings;


public interface TrainingsService {
 public List<Trainings> getTrainingsDetails();

public Trainings createTraining(Trainings trainings);

public Trainings approveTrainings(Trainings trainings);

public List<Trainings> getCompletedTrainings(long uid);

public List<Trainings> getUnderProgressTrainings(long uid);

public List<Trainings> getApprovedTraining(long uid);
}
