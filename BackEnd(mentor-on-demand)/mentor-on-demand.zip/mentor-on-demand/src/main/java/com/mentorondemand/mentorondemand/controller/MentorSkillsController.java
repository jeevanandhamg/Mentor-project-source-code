package com.mentorondemand.mentorondemand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.mentorondemand.model.MentorSkills;
import com.mentorondemand.mentorondemand.service.MentorSkillsService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/mentorskills")
public class MentorSkillsController {

	@Autowired
	private MentorSkillsService mentorSkillsService;
	
	//get all mentor skills details 
		@GetMapping(value="/mentorskills")
		public List<MentorSkills> getAllMentorSkills()
		{
			return mentorSkillsService.getAllMentorSkills();
		}
		
		@PostMapping(value="/update")
		public MentorSkills  updateMentorSkills(@RequestBody MentorSkills mentorSkills)
		{
			
			return mentorSkillsService.updateMentorSkills(mentorSkills);
			
		}
	
}
