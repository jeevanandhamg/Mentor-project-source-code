package com.mentorondemand.mentorondemand.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.mentorondemand.model.Trainings;

import com.mentorondemand.mentorondemand.repository.TrainingsRepository;

@Service
public class TrainingsServiceImpl implements TrainingsService{

	@Autowired
	TrainingsRepository trainingsRepository;

	@Override
	public List<Trainings> getTrainingsDetails() {
		// TODO Auto-generated method stub
		return trainingsRepository.findAll();
	}

	@Override
	public Trainings createTraining(Trainings trainings) {
		// TODO Auto-generated method stub
		return trainingsRepository.save(trainings);
	}

	@Override
	public Trainings approveTrainings(Trainings trainings) {
		// TODO Auto-generated method stub
		return trainingsRepository.save(trainings);
	}

	@Override
	public List<Trainings> getCompletedTrainings(long uid) {
		// TODO Auto-generated method stub
		return trainingsRepository.getCompletedTrainings(uid);
	}

	@Override
	public List<Trainings> getUnderProgressTrainings(long uid) {
		// TODO Auto-generated method stub
		return trainingsRepository.getUnderProgressTrainings(uid);
	}

	@Override
	public List<Trainings> getApprovedTraining(long uid) {
		// TODO Auto-generated method stub
		return trainingsRepository.getApprovedTraining(uid);
	}
	
	
	
	
}
