package com.mentorondemand.mentorondemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.mentorondemand.mentorondemand.model.Admin;

public interface AdminRepository extends JpaRepository<Admin, Long>{

	@Query("Select a From Admin a where a.userName = :uname and a.password = :password" )
	Admin loginAdminCheck(@Param("uname") String uname,@Param("password") String password);



}
