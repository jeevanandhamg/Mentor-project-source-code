package com.mentorondemand.mentorondemand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.mentorondemand.model.Mentor;
import com.mentorondemand.mentorondemand.service.MentorService;

@CrossOrigin(origins="http://localhost:4200")
@RestController
@RequestMapping("/mentor")
public class MentorController {

	@Autowired
	private MentorService mentorService;
	
	//get all mentor details 
	@GetMapping(value="/mentors")
	public List<Mentor> getAllMentor()
	{
		return mentorService.getAllMentor();
	}
	
	//login mentor
	@GetMapping(value="/loginMentor/{uname}/{password}")
	public Mentor loginMentorCheck(@PathVariable("uname") String uname,@PathVariable("password") String password)
	{
		
		return mentorService.loginMentorCheck(uname,password);
		
	}
	
	//signup mentor
	@PostMapping(value="/signupMentor")
	public Mentor signupMentor(@RequestBody Mentor mentor)
	{
		return mentorService.signupMentor(mentor);
	}
	
	@PostMapping(value="/blockmentor")
	public Mentor blockMentor(@RequestBody Mentor mentor)
	{
		return mentorService.blockMentor(mentor);
	}
	
}
