package com.mentorondemand.mentorondemand.service;

import java.util.List;


import com.mentorondemand.mentorondemand.model.Mentor;

public interface MentorService {

	public List<Mentor> getAllMentor();

	public Mentor loginMentorCheck(String uname, String password);

	public Mentor signupMentor(Mentor mentor);
}
