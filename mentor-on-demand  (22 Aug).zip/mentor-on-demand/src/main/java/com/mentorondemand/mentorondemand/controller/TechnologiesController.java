package com.mentorondemand.mentorondemand.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mentorondemand.mentorondemand.model.Technologies;
import com.mentorondemand.mentorondemand.service.TechnologiesService;

@RestController
@RequestMapping("/technologies")
public class TechnologiesController {

	@Autowired
	TechnologiesService technologiesService;
	
	@GetMapping(value="technologies")
	public List<Technologies> getAllTechnologies()
	{
		return technologiesService.getAllTechnologies();
		
	}
}
