package com.mentorondemand.mentorondemand.service;

import java.util.List;

import com.mentorondemand.mentorondemand.model.Technologies;

public interface TechnologiesService {

	public List<Technologies> getAllTechnologies();

}
