package com.mentorondemand.mentorondemand.service;

public interface MentorSkillsService {

}
