package com.mentorondemand.mentorondemand.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mentorondemand.mentorondemand.model.Admin;
import com.mentorondemand.mentorondemand.repository.AdminRepository;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	AdminRepository adminRepository;
	
	@Override
	public Admin loginAdminCheck(String uname, String password) {
		// TODO Auto-generated method stub
		return adminRepository.loginAdminCheck(uname,password);
	}

	@Override
	public Admin signupAdmin(Admin admin) {
		// TODO Auto-generated method stub
		return adminRepository.save(admin);
	}

}
