import { Component, OnInit } from '@angular/core';
import 'C:/Users/768678/Desktop/Angular project/mentorProject/src/app/scripts/showPassword.js';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
