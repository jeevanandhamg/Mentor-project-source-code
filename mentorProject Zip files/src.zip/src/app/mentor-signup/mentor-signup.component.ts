import { Component, OnInit } from '@angular/core';
import 'C:/Users/768678/Desktop/Angular project/mentorProject/src/app/scripts/confirmPassword.js';
@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
