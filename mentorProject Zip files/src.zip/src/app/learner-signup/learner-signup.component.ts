import { Component, OnInit } from '@angular/core';
import 'C:/Users/768678/Desktop/Angular project/mentorProject/src/app/scripts/confirmPassword.js';

@Component({
  selector: 'app-learner-signup',
  templateUrl: './learner-signup.component.html',
  styleUrls: ['./learner-signup.component.css']
})
export class LearnerSignupComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
