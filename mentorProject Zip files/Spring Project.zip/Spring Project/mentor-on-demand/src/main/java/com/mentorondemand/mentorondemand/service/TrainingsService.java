package com.mentorondemand.mentorondemand.service;

import java.util.List;

import com.mentorondemand.mentorondemand.model.Trainings;

public interface TrainingsService {
 public List<Trainings> getTrainingsDetails();
}
