package com.mentorondemand.mentorondemand.service;

import java.util.List;


import com.mentorondemand.mentorondemand.model.Mentor;

public interface MentorService {

	public List<Mentor> getMentorDetails();
}
