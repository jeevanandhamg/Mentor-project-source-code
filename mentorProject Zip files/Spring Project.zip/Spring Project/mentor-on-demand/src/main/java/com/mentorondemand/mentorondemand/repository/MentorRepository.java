package com.mentorondemand.mentorondemand.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mentorondemand.mentorondemand.model.Mentor;

public interface MentorRepository extends JpaRepository<Mentor, Long>{

}
