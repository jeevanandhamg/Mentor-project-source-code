
export class User
{
    id:number;
    userName:String;
    password:String;
    firstName:String;
    lastName:String;
    contactNumber:String;
    regDateTime:Date;
    regCode:number;
    active:boolean;
    }