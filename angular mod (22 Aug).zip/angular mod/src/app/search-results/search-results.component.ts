import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { MentorService } from '../mentor/mentor.service';
import { Mentor } from '../mentor/MentorModel';
import { Technologies } from '../Technologies/TechnologiesModel';
import { TechnologiesService } from '../Technologies/technologies.service';
import { MentorSkills } from '../MentorSkills/MentorSkillsModel';
import { MentorSkillsService } from '../MentorSkills/mentor-skills.service';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.css']
})
export class SearchResultsComponent implements OnInit {

  mentor: Observable<Mentor[]>;
  technologies:Observable<Technologies[]>;
  mentorSkills:Observable<MentorSkills[]>;
  constructor(private mentorService:MentorService,private technologiesService:TechnologiesService,private mentorSkillsService:MentorSkillsService) { }

  ngOnInit() {
    this.reloadData();
  }

  reloadData()
  {
    this.mentor=this.mentorService.getAllMentor();
    this.technologies=this.technologiesService.getAllTechnologies();
    this.mentorSkills=this.mentorSkillsService.getAllMentorSkills();
  }
}
