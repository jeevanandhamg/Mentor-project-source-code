import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Mentor } from './MentorModel';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  constructor() { }

  getAllMentor():Observable<any>
  {
    return null;
  }
  mentorLoginCheck(mentorUName:String,mentorPassword:String):Observable<any>
  {
    return null;
  }
  mentorSignup(mentor:Mentor):Observable<any>
  {
    return null;
  }
}
