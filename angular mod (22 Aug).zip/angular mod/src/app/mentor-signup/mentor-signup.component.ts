import { Component, OnInit } from '@angular/core';
import 'C:/Users/Admin/Desktop/angular/mentor-on-demand/src/app/scripts/confirmPassword.js';
import { Mentor } from '../mentor/MentorModel';
import { MentorService } from '../mentor/mentor.service';
import { Technologies } from '../Technologies/TechnologiesModel';
import { Observable } from 'rxjs';
import { TechnologiesService } from '../Technologies/technologies.service';
import { MentorSkills } from '../MentorSkills/MentorSkillsModel';
import { MentorSkillsService } from '../MentorSkills/mentor-skills.service';
@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  constructor(private mentorService:MentorService,private technologiesService:TechnologiesService,private mentorSkillsService:MentorSkillsService) { }

  technologies:Observable<Technologies[]>;

mentor:Mentor=new Mentor();
mentorSkills:MentorSkills=new MentorSkills();
  ngOnInit() {
    this.technologies=this.technologiesService.getAllTechnologies();
  }
  
private onSubmitMentorSignup()
{
  this.mentorService.mentorSignup(this.mentor)
  .subscribe((mentor:Mentor) => {
    this.mentor=mentor
  }
  );

  this.mentorSkills.mid=this.mentor;
  this.mentorSkills.yearOfExperience=this.mentor.yearOfExperience;
  this.updateMentorSkills();
  this.mentor= new Mentor();
  this.mentorSkills=new MentorSkills();
}

private updateMentorSkills()
{
  this.mentorSkillsService.updateMentorSkills(this.mentorSkills);
}

  onSubmitMentor()
  {
    this.onSubmitMentorSignup();
  }


}
