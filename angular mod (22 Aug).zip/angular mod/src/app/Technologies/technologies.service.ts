import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class TechnologiesService {

  private baseUrl = 'http://localhost:9531/technologies';

  constructor(private http: HttpClient) { }
  getAllTechnologies():Observable<any>
  {
    return this.http.get(`${this.baseUrl}` + `/technologies`);
  }
}
