export class Technologies
{
    id:number;
    name:String;
    TOC:String;
    duration:String;
    preRequites:String;
}