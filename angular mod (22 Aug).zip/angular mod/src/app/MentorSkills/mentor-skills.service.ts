import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MentorSkills } from './MentorSkillsModel';

@Injectable({
  providedIn: 'root'
})
export class MentorSkillsService {

  constructor() { }
  getAllMentorSkills():Observable<any>
  {
    return null;
  }

  updateMentorSkills(mentorSkills:MentorSkills):Observable<any>
  {
    return null;
  }
}
