import { Component, OnInit } from '@angular/core';
import '../scripts/showPassword.js';
import { UserService } from '../user/user.service';
import { MentorService } from '../mentor/mentor.service';
import { User } from '../user/UserModel';
import { Mentor } from '../mentor/MentorModel';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService:UserService,private mentorService:MentorService,private router:Router) { }

  userUName:String;
  userPassword:String;
  mentorUName:String;
  mentorPassword:String;

  userWrongCredentials=true;
  mentorWrongCredentials=true;

  user:User=new User();
  mentor:Mentor=new Mentor();
  ngOnInit() {
   
  }

 private onSubmitUserLogin()
  {
    this.userService.userLoginCheck(this.userUName,this.userPassword)
    .subscribe((user:User) => 
    {
      this.user=user;
      console.log(this.user);
    });
    if(this.user==null)
    {
      this.userWrongCredentials=false;
    }
    else
    {
      this.router.navigate(['/userHomePage']);
    }
  }
  private onSubmitMentorLogin()
  {
  this.mentorService.mentorLoginCheck(this.mentorUName,this.mentorPassword)
  .subscribe((mentor:Mentor) => {
    this.mentor=mentor;
    console.log(this.mentor);
  });
  if(this.mentor==null)
  {
    this.mentorWrongCredentials=false;
  }
  else
  {

  }
  }

  onSubmitUser()
  {
    this.onSubmitUserLogin();
  }
  onSubmitMentor()
  {
    this.onSubmitMentorLogin();
  }

}
