import { Component, OnInit } from '@angular/core';
import { Trainings } from 'src/app/trainings/TrainingsModel';
import { TrainingsService } from 'src/app/trainings/trainings.service';
import { Mentor } from '../MentorModel';

@Component({
  selector: 'app-mentor-home-page',
  templateUrl: './mentor-home-page.component.html',
  styleUrls: ['./mentor-home-page.component.css']
})
export class MentorHomePageComponent implements OnInit {

  pHidden:boolean=true;
  inProgressHidden:boolean=true;
  cHidden:boolean=true;

  allTrainings:Trainings[]=[]
  pTrainings: Trainings[]=[];
  inProgressTrainings: Trainings[]=[];
  cTrainings:Trainings[]=[];
  mentor:Mentor=new Mentor();

  constructor(private trainingsService:TrainingsService) { }

  ngOnInit() {
    this.mentor=JSON.parse(localStorage.getItem('mentor'));
    this.reloadData();
  }
  reloadData()
  {
    this.pTrainings=[];
    this.inProgressTrainings=[];
    this.cTrainings=[];

    this.trainingsService.getAllTrainings()
    .subscribe((response: Trainings[]) => {
        this.checkAllTrainings(response)
      }
    );

   
  }
  
  checkAllTrainings(trainings:Trainings[])
  {
    this.allTrainings=trainings;
    console.log(this.allTrainings);
    for(let i of this.allTrainings){

      if(i.mid.id==this.mentor.id)
      {
       if(i.status==2)
       {
         this.pTrainings.push(i);
       }
       if(i.status==5)
       {
         this.inProgressTrainings.push(i);
       }
       if(i.status==6)
       {
         this.cTrainings.push(i);
       }

      }
    }

    console.log(this.pTrainings);
    if(this.pTrainings.length==0)
    {
      this.pHidden=false;
    }
    else{
      this.pHidden=true;
    }

    if(this.inProgressTrainings.length==0)
    {
      this.inProgressHidden=false;
    }
    else{
      this.inProgressHidden=true;
    }

    if(this.cTrainings.length==0)
    {
      this.cHidden=false;
    }
    else{
      this.cHidden=true;
    }

  }
   
  accept(t:Trainings)
  {
    t.status=3;
    this.trainingsService.approve(t)
    .subscribe((response: Trainings) => {
      console.log(response);
      this.reloadData();
    }
  );

 
  
  }

  reject(t:Trainings)
  {
    t.status=0;
    this.trainingsService.approve(t)
    .subscribe((response: Trainings) => {
      console.log(response);
      this.reloadData();
    }
  );
 
  }

}
