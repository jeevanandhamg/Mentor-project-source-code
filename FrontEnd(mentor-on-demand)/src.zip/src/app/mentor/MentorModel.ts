export class Mentor
{
    id:number;
    userName:String;
    password:String;
    firstName:String;
    lastName:String;
    contactNumber:number;
    regDateTime:String;
    regCode:String;
    linkedinURL:String;
    yearOfExperience:number;
    active:boolean;
    }