import { Component, OnInit } from '@angular/core';
import { Mentor } from '../MentorModel';
import { MentorService } from '../mentor.service';

@Component({
  selector: 'app-mentor-block',
  templateUrl: './mentor-block.component.html',
  styleUrls: ['./mentor-block.component.css']
})
export class MentorBlockComponent implements OnInit {

  mentorList:Mentor[];
  constructor(private mentorService:MentorService) { }

  ngOnInit() {
    this.reloadData();
  }
  changeAccess(active:boolean,mentor:Mentor)
  {
    mentor.active=active;
    this.mentorService.blockMentor(mentor)
    .subscribe(
      (response:Mentor)=>{
        console.log(response);
      }
    );

    console.log(mentor);
  }

  reloadData()
  {
    this.mentorService.getAllMentor()
    .subscribe(
      (response:Mentor[])=>{
        this.checkMentor(response)
      }
    );
  }
  private checkMentor(response:Mentor[])
  {
    this.mentorList=response;
    console.log(this.mentorList);
  }
}
