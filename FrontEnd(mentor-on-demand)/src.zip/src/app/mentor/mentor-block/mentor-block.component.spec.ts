import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MentorBlockComponent } from './mentor-block.component';

describe('MentorBlockComponent', () => {
  let component: MentorBlockComponent;
  let fixture: ComponentFixture<MentorBlockComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MentorBlockComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MentorBlockComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
