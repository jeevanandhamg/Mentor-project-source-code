import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Mentor } from './MentorModel';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MentorService {

  private baseUrl = 'http://localhost:9531/mentor';
  constructor(private http: HttpClient) { }

  getAllMentor():Observable<Mentor[]>
  {
    return this.http.get<Mentor[]>(`${this.baseUrl}` + `/mentors`);
  }
  mentorLoginCheck(mentorUName:String,mentorPassword:String):Observable<any>
  {
    return this.http.get(`${this.baseUrl}/loginMentor/${mentorUName}/${mentorPassword}`);
  }
  mentorSignup(mentor:Mentor):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/signupMentor`, mentor);
  }
  blockMentor(mentor:Mentor): Observable<any>
 {

 return  this.http.post(`${this.baseUrl}` + `/blockmentor`, mentor); 
 }

} 
