import { Component, OnInit } from '@angular/core';
import '../scripts/confirmPassword.js';
import { Mentor } from '../mentor/MentorModel';
import { MentorService } from '../mentor/mentor.service';
import { Technologies } from '../Technologies/TechnologiesModel';
// import { Observable } from 'rxjs';
import { TechnologiesService } from '../Technologies/technologies.service';
import { MentorSkills } from '../MentorSkills/MentorSkillsModel';
import { MentorSkillsService } from '../MentorSkills/mentor-skills.service';
import '../scripts/showPassword.js';
@Component({
  selector: 'app-mentor-signup',
  templateUrl: './mentor-signup.component.html',
  styleUrls: ['./mentor-signup.component.css']
})
export class MentorSignupComponent implements OnInit {

  technologies:Technologies[];

  constructor(private mentorService:MentorService,private technologiesService:TechnologiesService,private mentorSkillsService:MentorSkillsService) { 
   
  }

 

  

mentor:Mentor=new Mentor();
tech:Technologies=new Technologies()
mentorSkills:MentorSkills=new MentorSkills();

  ngOnInit() {
    this.technologiesService.getAllTechnologies()
    .subscribe((technologies:Technologies[]) => {
      this.technologies=technologies;
      
      this.sendTechnologiesObject(technologies);
    }
    );
    
  }
  private sendTechnologiesObject(technologies:Technologies[])
  {
    this.technologies=technologies;
    console.log(this.technologies);
  }
  
private onSubmitMentorSignup()
{
  this.mentor.active=true;
  this.mentorService.mentorSignup(this.mentor)
  .subscribe((mentor:Mentor) => {
    

    this.sendMentorObject(mentor);
  }
  );

 
}

private sendMentorObject(mentor:Mentor)
{
this.mentor=mentor;
console.log(this.mentor);

console.log(this.tech.id);
for(var i of this.technologies){
  if(i.id==this.tech.id)
  {
  
    
    this.tech.name=i.name
    this.tech.preRequites=i.preRequites
    this.tech.toc=i.toc
    this.tech.duration=i.duration
    this.mentorSkills.tid=this.tech;
  }
}

this.mentorSkills.tid=this.tech;
this.mentorSkills.mid=this.mentor;
this.mentorSkills.yearOfExperience=this.mentor.yearOfExperience;

console.log(this.mentorSkills);
this.mentorSkillsService.updateMentorSkills(this.mentorSkills).subscribe(
  (response:MentorSkills)=>{
    console.log("updated");
  }
);

this.mentor= new Mentor();
this.mentorSkills=new MentorSkills();
}



  onSubmitMentor()
  {
    this.onSubmitMentorSignup();
  }


}
