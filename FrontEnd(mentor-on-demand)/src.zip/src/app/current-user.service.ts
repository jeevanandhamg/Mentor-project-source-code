import { Injectable } from '@angular/core';
import { User } from './user/UserModel';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CurrentUserService {

  constructor() { }
  
  currentUser:number=1;
  // userChanged=new Subject<User>();

  // setCurrentUser(user:User){
  //   this.currentUser=user;
  //   this.userChanged.next(this.currentUser)

  //   console.log(this.currentUser)
  // }

 
}
