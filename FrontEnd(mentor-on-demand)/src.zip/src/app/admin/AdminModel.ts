export class Admin
{
    id:number;
    userName:String;
    password:String;
}