import { Component, OnInit } from '@angular/core';
import { AdminService } from './admin.service';
import { Admin } from './AdminModel';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  adminUName:String;
  adminPassword:String;

  adminWrongCredentials=true;
  constructor(private adminService:AdminService,private router:Router) { }


  admin:Admin=new Admin();
  ngOnInit() {
  }

  private onSubmitAdminLogin()
  {
    this.adminService.adminLoginCheck(this.adminUName,this.adminPassword)
    .subscribe((admin:Admin) => 
    {
      this.admin=admin;
      if(this.admin==null)
    {
      this.adminWrongCredentials=false;
      console.log("wrong password");
      
    }
    else
    {
      console.log("correct password");
      this.adminWrongCredentials=true;
      this.router.navigate(['/adminHomePage']);
    }
    console.log(this.admin);
    });
  }

  onSubmitAdmin()
  {
    this.onSubmitAdminLogin();
  }
}
