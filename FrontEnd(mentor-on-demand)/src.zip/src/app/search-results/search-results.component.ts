import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { MentorService } from '../mentor/mentor.service';
import { Mentor } from '../mentor/MentorModel';
import { Technologies } from '../Technologies/TechnologiesModel';
import { TechnologiesService } from '../Technologies/technologies.service';
import { MentorSkills } from '../MentorSkills/MentorSkillsModel';
import { MentorSkillsService } from '../MentorSkills/mentor-skills.service';
import { Trainings } from '../trainings/TrainingsModel';
import { TrainingsService } from '../trainings/trainings.service';
import { User } from '../user/UserModel';
import { CurrentUserService } from '../current-user.service';

@Component({
  selector: 'app-search-results',
  templateUrl: './search-results.component.html',
  styleUrls: ['./search-results.component.css']
})
export class SearchResultsComponent implements OnInit {

  user: User=new User() ;
 ct:Trainings=new Trainings();

 hideProposeBtn:boolean=true;



  mentor: Mentor[];
  technologies: Technologies[];
  mentorSkills: MentorSkills[];
  trainings: Trainings[];
  constructor(private mentorService: MentorService, private technologiesService: TechnologiesService, private mentorSkillsService: MentorSkillsService, private trainingsService: TrainingsService, private currentUserService: CurrentUserService) { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem('user'));
    // console.log("id is "+this.currentUserService.currentUser);
    
    this.reloadData();
      
  }

 reloadData() {
  
    this.mentorService.getAllMentor()
      .subscribe(
        (response: Mentor[]) => {
          this.checkMentor(response)
        }
      );

    this.technologiesService.getAllTechnologies()
      .subscribe(
        (response: Technologies[]) => {
          this.checkTechnologies(response)
        }
      );

    this.mentorSkillsService.getAllMentorSkills()
      .subscribe(
        (response: MentorSkills[]) => {
          this.checkMentorSkills(response)
        }
      );

    this.trainingsService.getAllTrainings()
      .subscribe(
        (response: Trainings[]) => {
          this.checkTrainings(response)
        }
      );

  }
  checkMentor(mentor: Mentor[]) {
    this.mentor = mentor;
    console.log(this.mentor);
  }

  checkTechnologies(technologies: Technologies[]) {
    this.technologies = technologies;
    console.log(this.technologies);
  }

  checkMentorSkills(mentorSkills: MentorSkills[]) {
    this.mentorSkills = mentorSkills;
    console.log(this.mentorSkills);
  }

  checkTrainings(trainings: Trainings[]) {
    this.trainings = trainings;
    console.log(this.trainings);
  }
  
  createTraining(mentor: Mentor, technology: Technologies) {
    console.log("jeeva");
    console.log("pro is "+this.currentUserService.currentUser);
  
    console.log("local storage :"+this.user);
    this.ct.mid = mentor;
    this.ct.uid = this.user;
    this.ct.tid = technology;
    this.ct.status = 2;

    this.trainingsService.createTraining(this.ct)
      .subscribe((response: Trainings) => {
        console.log(response);
      }
      );
      this.reloadData();
  }

  finalizeTraining(trainings:Trainings)
  {
    trainings.status=4;
    this.trainingsService.finalizeTraining(trainings)
      .subscribe((response: Trainings) => {
        console.log(response);
      }
      );
      this.reloadData();
  }

  pay(trainings:Trainings)
  {
    trainings.status=5;
    this.trainingsService.pay(trainings)
      .subscribe((response: Trainings) => {
        console.log(response);
      }
      );
      this.reloadData();
  }
}
