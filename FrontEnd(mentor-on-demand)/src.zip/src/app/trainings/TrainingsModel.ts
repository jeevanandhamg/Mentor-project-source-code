import { User } from '../user/UserModel';
import { Mentor } from '../mentor/MentorModel';
import { Technologies } from '../Technologies/TechnologiesModel';

export class Trainings
{
    id:number;
    uid:User;
    mid:Mentor;
    tid:Technologies;
    status:number;
    startDate:String;
    endDate:String;
    amountReceived:String;

}