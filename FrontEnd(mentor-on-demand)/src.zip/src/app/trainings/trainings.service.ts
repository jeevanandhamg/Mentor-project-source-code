import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Trainings } from './TrainingsModel';
import { Observable } from 'rxjs';
import { User } from '../user/UserModel';

@Injectable({
  providedIn: 'root'
})
export class TrainingsService {

  constructor(private http: HttpClient) { }

  private baseUrl = 'http://localhost:9531/trainings';

  getAllTrainings():Observable<Trainings[]>
  {
    return this.http.get<Trainings[]>(`${this.baseUrl}` + `/trainings`);
  }

  createTraining(ct:Trainings):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/create`,ct);
  }

  finalizeTraining(trainings:Trainings):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/create`,trainings);
  }

  pay(trainings:Trainings):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/create`,trainings);
  }

  getProposedTrainings(user:User):Observable<Trainings[]>
  {
    return this.http.get<Trainings[]>(`${this.baseUrl}` + `/proposedAndApproved/${user.id}`);
  }

  getCompletedTrainings(user:User):Observable<Trainings[]>
  {
    return this.http.get<Trainings[]>(`${this.baseUrl}` + `/completed/${user.id}`);
  }

  getUnderProgressTrainings(user:User):Observable<Trainings[]>
  {
    return this.http.get<Trainings[]>(`${this.baseUrl}` + `/underprogress/${user.id}`);
  }

  approve(t:Trainings):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/approve`,t);
  }

}
