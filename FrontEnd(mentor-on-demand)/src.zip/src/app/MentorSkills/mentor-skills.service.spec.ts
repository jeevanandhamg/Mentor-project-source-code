import { TestBed } from '@angular/core/testing';

import { MentorSkillsService } from './mentor-skills.service';

describe('MentorSkillsService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: MentorSkillsService = TestBed.get(MentorSkillsService);
    expect(service).toBeTruthy();
  });
});
