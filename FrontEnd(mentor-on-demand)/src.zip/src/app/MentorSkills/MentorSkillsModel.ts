import { Mentor } from '../mentor/MentorModel';
import { Technologies } from '../Technologies/TechnologiesModel';

export class MentorSkills
{
    mid:Mentor;
    tid:Technologies;
    selfRating:String;
    yearOfExperience:number;
    trainingsDelivered:String;
    facilitiesOffered:String;
}