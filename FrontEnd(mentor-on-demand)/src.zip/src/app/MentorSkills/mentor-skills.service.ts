import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { MentorSkills } from './MentorSkillsModel';
import { HttpClient } from '@angular/common/http';
import { Technologies } from '../Technologies/TechnologiesModel';

@Injectable({
  providedIn: 'root'
})
export class MentorSkillsService {

  private baseUrl = 'http://localhost:9531/mentorskills';

  constructor(private http: HttpClient) { }
  getAllMentorSkills():Observable<MentorSkills[]>
  {
    return this.http.get<MentorSkills[]>(`${this.baseUrl}` + `/mentorskills`);
  }

  updateMentorSkills(mentorSkills:MentorSkills):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/update`, mentorSkills);
  }
}
