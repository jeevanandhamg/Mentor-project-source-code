import { Component, OnInit } from '@angular/core';
import { Trainings } from 'src/app/trainings/TrainingsModel';
import { TrainingsService } from 'src/app/trainings/trainings.service';
import { User } from '../UserModel';
import 'C:/Users/Admin/Desktop/angular/mentor-on-demand/src/app/scripts/showPassword.js';

@Component({
  selector: 'app-progress',
  templateUrl: './progress.component.html',
  styleUrls: ['./progress.component.css']
})
export class ProgressComponent implements OnInit {

  pHidden:boolean=true;
  inProgressHidden:boolean=true;
  cHidden:boolean=true;

  pTrainings: Trainings[];
  inProgressTrainings: Trainings[];
  cTrainings:Trainings[];
  user:User=new User();

  constructor(private trainingsService:TrainingsService) { }

  ngOnInit() {
    this.user=JSON.parse(localStorage.getItem('user'));
    this.reloadData();
  }
  reloadData()
  {
    this.trainingsService.getProposedTrainings(this.user)
    .subscribe(
      (response: Trainings[]) => {
        this.checkProposedTrainings(response)
      }
    );

    this.trainingsService.getCompletedTrainings(this.user)
    .subscribe(
      (response: Trainings[]) => {
        this.checkCompletedTrainings(response)
      }
    );

    this.trainingsService.getUnderProgressTrainings(this.user)
    .subscribe(
      (response: Trainings[]) => {
        this.checkUnderProgressTrainings(response)
      }
    );
  }

  checkProposedTrainings(trainings:Trainings[])
  {
    this.pTrainings=trainings;
    console.log(this.pTrainings);
    if(this.pTrainings.length==0)
    {
      this.pHidden=false;
    }
    else{
      this.pHidden=true;
    }
  }

  checkUnderProgressTrainings(trainings:Trainings[])
  {
    this.inProgressTrainings=trainings;
    console.log(this.inProgressTrainings);
    if(this.inProgressTrainings.length==0)
    {
      this.inProgressHidden=false;
    }
    else{
      this.inProgressHidden=true;
    }
  }

  checkCompletedTrainings(trainings:Trainings[])
  {
    this.cTrainings=trainings;
    console.log(this.cTrainings);
    if(this.cTrainings.length==0)
    {
      this.cHidden=false;
    }
    else{
      this.cHidden=true;
    }
  }

  pay(trainings:Trainings)
  {
    trainings.status=5;
    this.trainingsService.pay(trainings)
      .subscribe((response: Trainings) => {
        console.log(response);
        this.reloadData();
      }
      );
     
  }

  markAsCompleted(trainings:Trainings)
  {
    trainings.status=6;
    this.trainingsService.pay(trainings)
      .subscribe((response: Trainings) => {
        console.log(response);
        this.reloadData();
      }
      );
     
  }


}
