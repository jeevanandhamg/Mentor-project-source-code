import { Component, OnInit } from '@angular/core';
import { User } from '../UserModel';
import { UserService } from '../user.service';

@Component({
  selector: 'app-user-block',
  templateUrl: './user-block.component.html',
  styleUrls: ['./user-block.component.css']
})
export class UserBlockComponent implements OnInit {

  userList:User[];
  constructor(private userService:UserService) { }

  ngOnInit() {
    this.reloadData();
  }

  changeAccess(active:boolean,user:User)
  {
    user.active=active;
    this.userService.blockUser(user)
    .subscribe(
      (response:User)=>{
        console.log(response);
      }
    );

    console.log(user);
  }

  reloadData()
  {
    this.userService.getAllUser()
    .subscribe(
      (response:User[])=>{
        this.checkUser(response)
      }
    );
  }
  private checkUser(response:User[])
  {
    this.userList=response;
    
    console.log(this.userList);
  }

}
