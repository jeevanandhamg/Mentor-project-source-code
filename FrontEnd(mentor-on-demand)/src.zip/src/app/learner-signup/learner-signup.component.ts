import { Component, OnInit } from '@angular/core';
import '../scripts/confirmPassword.js';
import '../scripts/showPassword.js';
import { User } from '../user/UserModel';
import { UserService } from '../user/user.service';

@Component({
  selector: 'app-learner-signup',
  templateUrl: './learner-signup.component.html',
  styleUrls: ['./learner-signup.component.css']
})
export class LearnerSignupComponent implements OnInit {

  user:User=new User();

  constructor(private userService:UserService) { }

  ngOnInit() {
  }

  private onSubmitUserSignup()
  {
    this.user.active=true;
    this.userService.userSignup(this.user)
    .subscribe((user:User) => {
      this.user=user
      console.log(this.user);
    });
    this.user= new User();
  }

  onSubmitUser(){

    this.onSubmitUserSignup();
  

  }

}
