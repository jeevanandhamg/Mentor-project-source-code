import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Technologies } from './TechnologiesModel';
import { MentorSkills } from '../MentorSkills/MentorSkillsModel';

@Injectable({
  providedIn: 'root'
})
export class TechnologiesService {

  private baseUrl = 'http://localhost:9531/technologies';

  constructor(private http: HttpClient) { }
  getAllTechnologies():Observable<Technologies[]>
  {
    return this.http.get<Technologies[]>(`${this.baseUrl}` + `/technologies`);
  }

  createTechnology(technologies:Technologies):Observable<any>
  {
    return this.http.post(`${this.baseUrl}` + `/create`,technologies);
  }
}
