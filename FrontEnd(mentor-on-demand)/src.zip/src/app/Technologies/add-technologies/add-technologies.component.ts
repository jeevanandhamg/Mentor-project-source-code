import { Component, OnInit } from '@angular/core';
import { TechnologiesService } from '../technologies.service';
import { Technologies } from '../TechnologiesModel';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-technologies',
  templateUrl: './add-technologies.component.html',
  styleUrls: ['./add-technologies.component.css']
})
export class AddTechnologiesComponent implements OnInit {
  constructor(private technologyService:TechnologiesService,private router:Router) { }

  ngOnInit() {
  }

  technologies:Technologies=new Technologies();

  private addTechnology()
  {
    this.technologyService.createTechnology(this.technologies)
    .subscribe((technologies:Technologies) => {
      this.technologies=technologies;
      console.log(this.technologies);
      this.router.navigate(['/adminHomePage']);
    }
    );
    
  }

  tech()
  {
    this.addTechnology();
  }
}
