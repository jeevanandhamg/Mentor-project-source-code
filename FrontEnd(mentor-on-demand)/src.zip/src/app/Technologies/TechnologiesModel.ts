export class Technologies
{
    id:number;
    name:String;
    toc:String;
    duration:String;
    preRequites:String;
}