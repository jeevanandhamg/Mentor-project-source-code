import { Component, OnInit } from '@angular/core';
import '../scripts/showPassword.js';
import { UserService } from '../user/user.service';
import { MentorService } from '../mentor/mentor.service';
import { User } from '../user/UserModel';
import { Mentor } from '../mentor/MentorModel';
import { Router } from '@angular/router';
import { CurrentUserService } from '../current-user.service.js';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(private userService:UserService,private mentorService:MentorService,private router:Router,private currentUserService:CurrentUserService) { }

  userUName:String;
  userPassword:String;
  mentorUName:String;
  mentorPassword:String;

  userWrongCredentials=true;
  mentorWrongCredentials=true;

  user:User=new User();
  mentor:Mentor=new Mentor();
  ngOnInit() {
   
  }
 public cu:string
 
 private onSubmitUserLogin()
  {
    this.userService.userLoginCheck(this.userUName,this.userPassword)
    .subscribe((user:User) => 
    {
      this.user=user;
      if(this.user==null)
    {
      this.userWrongCredentials=false;
      console.log("wrong password");
      
    }
    else
    {
      console.log("correct password");
      this.userWrongCredentials=true;

      this.setCurrentUser(user);
        


      this.router.navigate(['/userHomePage']);
    }
    console.log(this.user);
   
    });
    
    
  }

  setCurrentUser(user:User)
  {
    
    localStorage.setItem('user', JSON.stringify(user));
  
  }
  

  private onSubmitMentorLogin()
  {
    
  this.mentorService.mentorLoginCheck(this.mentorUName,this.mentorPassword)
  .subscribe((mentor:Mentor) => {
    this.mentor=mentor;

    if(this.mentor==null)
  {
    this.mentorWrongCredentials=false;
  }
  else
  {
    console.log("correct password");
    localStorage.setItem('mentor', JSON.stringify(mentor));
    this.mentorWrongCredentials=true;

    this.router.navigate(['/mentorHomePage']);
  }

    console.log(this.mentor);
  });
  
  }

  onSubmitUser()
  {
    this.onSubmitUserLogin();
  }
  onSubmitMentor()
  {
    console.log(this.mentorUName);
    this.onSubmitMentorLogin();
  }

}
