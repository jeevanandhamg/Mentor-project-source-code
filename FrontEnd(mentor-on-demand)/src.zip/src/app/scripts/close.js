$(document).ready(function() {
$("#markAsCompleted").click(function() {
    $("#close").trigger('click');
  });
});